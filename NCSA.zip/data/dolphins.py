import matplotlib.pyplot as plt
import networkx as nx


G = nx.read_gml('D:/新都/数据集/dolphins/dolphins.gml')

pos = nx.spring_layout(G)
nx.draw(G,pos,with_labels=True,node_size=500,font_size=10)
nx.draw_networkx_edges(G,pos,width=1.0,alpha=0.5)
plt.show()