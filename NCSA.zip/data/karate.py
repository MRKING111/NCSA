import matplotlib.pyplot as plt
import networkx as nx
import pandas as pd

columns = ['Source','Target']
data = pd.read_excel('D:/新都/数据集/weighted_karateclub_dataset-main/karate weighted data.xlsx', names=columns, header=None)

graph = nx.Graph()
data_len = len(data)

for i in range(data_len):
    graph.add_edge(data.iloc[i]['Source'],data.iloc[i]['Target'])

nx.draw(graph,with_labels=True)
plt.show()