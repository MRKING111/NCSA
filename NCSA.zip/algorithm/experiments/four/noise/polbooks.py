import numpy as np
from scipy.optimize import minimize
from algorithm.Reconstruction_propagation.data import polbook_100times
# import time
import random as rand
# 记录开始时间
# start_time = time.time()
# 一范式函数定义
def objective(x):
    return np.linalg.norm(x, ord=1)

def num_01(lst):
    count = 0
    j = 0
    while j < len(l) - 1:
        # 检查当前元素和下一个元素是否满足条件
        if (l[j] == 0 and l[j + 1] == 1) or (l[j] == 1 and l[j + 1] == 1):
            count += 1
            # 标记已使用的元素
            l[j] = -1
            l[j + 1] = -1
            # 跳过已使用的元素
            j += 2
        else:
            j += 1
    return count

# ADMM
def admm_solver(A, b, rho, max_iters=100, tol=1e-4):
    # Initialize variables
    m, n = A.shape
    x = np.zeros(n)
    z = np.zeros(n)
    u = np.zeros(n)
    z_prev = np.zeros(n)  # Initialize z_prev

    # Define the augmented Lagrangian function
    def augmented_lagrangian(x, z, u):
        return 0.5 * np.linalg.norm(A.dot(x) - b)**2 + rho / 2 * np.linalg.norm(x - z + u)**2

    for iteration in range(max_iters):
        # Update x using the formula for the minimization subproblem
        x = np.linalg.solve(A.T.dot(A) + rho * np.eye(n), A.T.dot(b) + rho * (z - u))

        # Update z and u using the formula for the dual variable update
        z = np.maximum(0, x + u)
        u = u + x - z

        # Check for convergence
        primal_residual = np.linalg.norm(A.dot(x) - b)
        dual_residual = np.linalg.norm(rho * (z - z_prev))
        if primal_residual < tol and dual_residual < tol:
            break

        z_prev = z  # Store the previous value of z for the dual residual calculation

    return x

# 解决矩阵输出不完全
np.set_printoptions(threshold=np.inf)

# theta = 0.25
theta = 0.3

# ▲
# la = 0.45
la = 0.525
# la = 0.45best
# 状态矩阵
state_matrix = np.array(polbook_100times.matrix_80times_state)
state_T = state_matrix.T
l = []
nodes_center = []
# 计算每个节点状态01、11个数
for i in range(state_T.shape[0]):
    l = state_T[i:i+1,:].flatten().tolist()
    nodes_center.append(num_01(l))
# 首先，对列表进行排序，同时记录排序前的索引
sorted_pairs = sorted(enumerate(nodes_center), key=lambda x: x[1], reverse=True)
# 排序后的结果是元组列表，每个元组包含索引和值
# 现在我们可以根据值大小提取出索引的排列顺序
sorted_indices = [pair[0] for pair in sorted_pairs]

for mm in range(1000):
    # 噪音值
    noise_num = 30
    for i in range(noise_num):
        a = rand.randint(0, state_matrix.shape[0] - 1)
        b = rand.randint(0, state_matrix.shape[1] - 1)
        if state_matrix[a][b] == 1:
            state_matrix[a][b] = 0
        else:
            state_matrix[a][b] = 1

    # 邻接矩阵
    adj_matrix = np.array(polbook_100times.matrix_100times_adj)

    # 存储最终矩阵
    final_state_matrix = np.zeros((adj_matrix.shape[0], adj_matrix.shape[1]))

    # 网络节点数
    num_n = 106

    for i in range(state_matrix.shape[0]):
        change = sorted_indices[i]
        a = state_matrix[:, change:1 + change]
        matrix_cut = np.delete(state_matrix, change, axis=1)
        count = 0

        # 存储提取的平均矩阵
        avg = np.zeros((2, num_n - 1))
        # avg_p = np.zeros((2, 1))
        avg_p = np.zeros(2)
        # 只获取两个基本时间段的控制指标数
        c = 1
        flag = 0
        cut_off = []
        # 提取第一个基本时间段的循环
        for j in range(state_matrix.shape[0]):
            if count < state_matrix.shape[0] - 1 and a[count] == 0 and (
                    a[count + 1] == 0 or a[count + 1] == 1) and c == 1:
                flag = count + 1
                cut_off = matrix_cut[count]
                break
            else:
                count += 1

        # 创建空列表存储提取的数组
        store_matrix_1 = []
        store_matrix_2 = []
        # 存储当前压缩感知节点的状态
        matrix_p_1 = []
        matrix_p_2 = []

        for j in range(state_matrix.shape[0]):
            if count < state_matrix.shape[0] - 1 and a[count] == 0 and (a[count + 1] == 0 or a[count + 1] == 1):
                # 提取第二个基本时间段的判断
                if c == 1:
                    if a[flag] != a[count + 1] and dist_counter / len(cut_off) > theta:
                        cut_off = matrix_cut[count]
                        # print(f"value of cut_off_2{cut_off}")
                        c += 1
                dist_counter = 0
                for n in range(len(cut_off)):
                    if cut_off[n] != matrix_cut[count][n]:
                        dist_counter += 1
                    # 阈值判断
                # 存储基本时间段改变前后的两个矩阵信息la
                if c == 1:
                    if dist_counter / len(cut_off) < la:
                        matrix_p_1.append(a[count + 1])
                        store_matrix_1.append(matrix_cut[count])
                        # break
                if c == 2:
                    if dist_counter / len(cut_off) < la:
                        matrix_p_2.append(a[count + 1])
                        store_matrix_2.append(matrix_cut[count])
                count += 2
            else:
                count += 1

        store_matrix_1 = np.array(store_matrix_1)
        matrix_p_1 = np.array(matrix_p_1)
        new_store_matrix_1 = np.vstack(store_matrix_1)
        # 输出得到的matrix_1矩阵
        # print(f"the value of new_store_matrix_1:\n{new_store_matrix_1}")
        m_1 = new_store_matrix_1.shape[0]
        n_1 = new_store_matrix_1.shape[1]
        # 求第一个矩阵平均矩阵值
        for m in range(n_1):
            for n in range(m_1):
                avg[0][m] += new_store_matrix_1[n][m]
            avg[0][m] = avg[0][m] / m_1
        for m in range(matrix_p_1.shape[1]):
            avg_p[0] += matrix_p_1[m][0]
        avg_p[0] = avg_p[0] / matrix_p_1.shape[1]

        # 防止matrix_2矩阵为空矩阵不能进行vstack操作
        if c == 2:
            store_matrix_2 = np.array(store_matrix_2)
            matrix_p_2 = np.array(matrix_p_2)
            new_store_matrix_2 = np.vstack(store_matrix_2)
            # 在循环中输出得到的matrix_2，防止循环外不存在matrix_2矩阵报错
            # print(f"the value of new_store_matrix_2:\n{new_store_matrix_2}")
            m_2 = new_store_matrix_2.shape[0]
            n_2 = new_store_matrix_2.shape[1]
            # 求第二个矩阵平均矩阵值
            for m in range(n_2):
                for n in range(m_2):
                    avg[1][m] += new_store_matrix_2[n][m]
                avg[1][m] = avg[1][m] / m_2

            for m in range(matrix_p_2.shape[0]):
                avg_p[1] += matrix_p_2[m][0]
            avg_p[1] = avg_p[1] / matrix_p_2.shape[0]
        else:
            avg = np.delete(avg, 1, axis=0)
            avg_p = np.delete(avg_p, 1, axis=0)

        # print(f"the value of avg:\n{avg}")
        # print(f"value of matrix_p:\n{avg_p}")
        # print(f"value of i {i}")

        # 压缩感知
        matrix_p = avg_p
        A = avg

        constraints = ({'type': 'eq', 'fun': lambda x: np.dot(A, x) - matrix_p})
        initial_guess = np.zeros(num_n - 1)

        result = minimize(objective, initial_guess, constraints=constraints)
        # recovered_sparse_matrix = result.x
        recovered_matrix = result.x

        if __name__ == "__main__":
            # Define the problem data
            # A = np.array()
            # b = np.array([0, 0.89473684])
            A = avg
            b = avg_p
            rho = 1.0

            # Solve the problem using ADMM
            x = admm_solver(A, b, rho)

            # print("Optimal solution:", x)
            recovered_sparse_matrix = x

        # 将array转化为list将49list填充为50
        recovered_sparse_matrix = recovered_sparse_matrix.tolist()
        recovered_sparse_matrix.insert(i, 1)
        # 将list转化为array
        recovered_sparse_matrix = np.array(recovered_sparse_matrix)

        final_state_matrix[change] = recovered_sparse_matrix
    # print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
    # print(final_state_matrix)

    # final_state_matrix = np.reshape(final_state_matrix, (num_n, num_n))

    count1 = 0
    count1adj = 0
    count0adj = 0
    uneq = 0
    recons_ones = 0
    for i in range(num_n):
        for j in range(num_n):
            if adj_matrix[i][j] == 1:
                count1adj += 1
            else:
                count0adj += 1
            if final_state_matrix[i][j] == 1:
                recons_ones += 1
            if final_state_matrix[i][j] == adj_matrix[i][j] == 1:
                count1 += 1
            if final_state_matrix[i][j] == 1 and adj_matrix[i][j] == 0:
                uneq += 1

    FN = count1adj - count1
    TN = count0adj - uneq
    print(f"原网络总边数（P）：{count1adj}")
    print("正确重构率", count1 / count1adj)

