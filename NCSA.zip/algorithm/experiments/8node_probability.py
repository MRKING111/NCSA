import numpy as np
from scipy.optimize import minimize


matrix_p = np.array([2/3])
# matrix_y = np.zeros(a)

# for i in range(a):
#     matrix_p[i] = np.log(1-matrix_p[i])
#     print(matrix_p[i])


# node_0 time_series
# A = np.array([[0, 1, 0, 0.5, 0, 0, 0],
#               [0.5, 0.5, 0.5, 1, 0, 0, 1]])

# node_1 time_series
# A = np.array([[0, 1, 0.5, 0.5, 0, 0, 0],
#               # [1, 0, 1, 0, 1, 1, 0.5]
#               ])

# node_2 time_series
# A = np.array([[0, 1, 0, 1, 1, 0, 0],
              # [1, 0, 1, 0, 1, 1, 0.5]
              # ])

# node_3 time_series
# A = np.array([[0, 0, 1, 0, 0, 0, 0],
#              [0, 0.5, 1, 1, 0.5, 0.5, 0]])

# node_4 time_series
# A = np.array([[0, 0, 1, 0, 0, 0, 0],
#               [1, 0.5, 0, 0.5, 1, 0.5, 0]])

# node_5 time_series   只能确定Node-4
# A = np.array([[0, 0, 1, 1, 1, 0, 0],
#               # [0, 0.5, 0.5, 0.5, 1, 0, 1]
#               [0, 1, 1, 0, 1, 0, 1],
#               # [0, 0, 0, 1, 1, 0, 1]
#               ])
A = np.array([[0, 1/3, 2/3, 2/3, 1, 0, 2/3],
              # [0, 0.5, 0.5, 0.5, 1, 0, 1],
              # [0, 0, 0, 1, 1, 0, 1]
              ])

# node_6 time_series
# A = np.array([[0, 0, 1, 0.5, 0.5, 0, 0],
#               [0, 1, 0.5, 0, 1, 0.5, 0.5],
#               # [0, 0.5, 0.5, 0.5, 1, 0, 1]
#               ])

# node_7  time_serise
# A = np.array([[0, 0, 1, 0, 0.5, 0, 0],
#              [1, 1, 0, 0, 0, 1, 0],
#              [0.5, 0, 0, 1, 1, 1, 1]])


def objective(x):
    return np.linalg.norm(x, ord=1)


constraints = ({'type': 'eq', 'fun': lambda x: np.dot(A, x) - matrix_p})
initial_guess = np.zeros(7)

result = minimize(objective, initial_guess, constraints=constraints)
print(result)

recovered_sparse_matrix = result.x

# print(matrix_y)
print("\n恢复的稀疏矩阵：")
print(recovered_sparse_matrix)
