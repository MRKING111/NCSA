import networkx as nx
import numpy as np
from scipy.optimize import minimize

# 读取 GML 文件
file_path = 'D:/新都/数据集/dolphins/dolphins.gml'  # 替换为您的文件路径
G = nx.read_gml(file_path)

# 图的节点数和边数
num_nodes = G.number_of_nodes()
num_edges = G.number_of_edges()

# 构建邻接矩阵
adj_matrix = nx.adjacency_matrix(G).toarray()

# 压缩感知参数
compression_ratio = 0.5  # 压缩比例
m = int(num_nodes * compression_ratio)  # 压缩感知测量数

# 随机测量矩阵
measurement_matrix = np.random.randn(m, num_nodes)
measurement_matrix_a = np.pad(measurement_matrix,((0,0),(0,3782)),'constant',constant_values=(0,0))
print('measurement_matrix_a的大小',measurement_matrix_a.shape,'adj_matrix的大小',adj_matrix.flatten().shape)
print(measurement_matrix_a)

# measurement_matrix_a = measurement_matrix.reshape(62,31)
# print(measurement_matrix_a.shape)

# 将邻接矩阵映射到测量空间
compressed_measurements = np.dot(measurement_matrix_a, adj_matrix.flatten())

# 重建函数（L1 范数最小化）
def reconstruction_l1(x):
    return np.linalg.norm(x, ord=1)

# 优化问题求解
result = minimize(reconstruction_l1, np.zeros(num_nodes * num_nodes), constraints={'type': 'eq', 'fun': lambda x: np.dot(measurement_matrix_a, x) - compressed_measurements})
reconstructed_adj_matrix = result.x.reshape((num_nodes, num_nodes))

# 构建重建图
reconstructed_G = nx.Graph(reconstructed_adj_matrix)


# 打印重建图的基本信息
print("Reconstructed graph nodes:", reconstructed_G.nodes())
print("Reconstructed graph edges:", reconstructed_G.edges())


