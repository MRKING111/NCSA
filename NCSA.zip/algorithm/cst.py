import numpy as np
from scipy.optimize import minimize

a = 2
matrix_p = np.array([0.1, 0])
matrix_y = np.zeros(a)

for i in range(a):
    matrix_y[i] = np.log(1-matrix_p[i])

# y = [0., -0.22314355, -0.10536052, -0.10536052, -0.10536052, -0.35667494,
#  -0.10536052, -0.22314355, -0.22314355, -0.35667494, -0.22314355, -0.22314355,
#  -0.10536052, -0.10536052]

A = np.array([[ 0.5, 0, 0, 1, 1, 0, 0],
                         [ 1, 0, 0, 0, 0, 0, 0],
              ])

def objective(x):
    return np.linalg.norm(x, ord=1)

# A = np.array([[0, 0, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0],
#         [0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1],
#         [0, 0, 1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0],
#         [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 1],
#         [0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0],
#         [0, 1, 0, 1, 1, 1, 0, 1, 1, 1, 0, 1, 0, 0],
#         [0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0],
#         [1, 0, 0, 1, 0, 0, 1, 1, 1, 0, 1, 0, 0, 0],
#         ])

constraints = ({'type': 'eq', 'fun': lambda x: np.dot(A, x) - matrix_y})
initial_guess = np.zeros(7)

result = minimize(objective, initial_guess, constraints=constraints)
print(result)

recovered_sparse_matrix = result.x

# print(matrix_y)
print("\n恢复的稀疏矩阵：")
print(recovered_sparse_matrix)
