import numpy as np
from scipy.optimize import minimize
from algorithm.Reconstruction_propagation.data import canetscience_100times

# 一范式函数定义
def objective(x):
    return np.linalg.norm(x, ord=1)

# 解决矩阵输出不完全
np.set_printoptions(threshold=np.inf)

# theta = 0.25
theta = 0.3


# ▲
# la = 0.45
la = 0.4
# la = 0.45best
# 状态矩阵
state_matrix = np.array(canetscience_100times.matrix_80times_state)
# 邻接矩阵
adj_matrix = np.array(canetscience_100times.matrix_100times_adj)


# 存储最终矩阵
final_state_matrix = []

# 网络节点数
num_n = 379

for i in range(state_matrix.shape[1]):
    a = state_matrix[:, i:1 + i]
    matrix_cut = np.delete(state_matrix, i, axis=1)
    count = 0

    # 存储提取的平均矩阵
    avg = np.zeros((2, num_n-1))
    # avg_p = np.zeros((2, 1))
    avg_p = np.zeros(2)
    # 只获取两个基本时间段的控制指标数
    c = 1
    flag = 0
    cut_off = []
    # 提取第一个基本时间段的循环
    for j in range(state_matrix.shape[0]):
        if count < state_matrix.shape[0]-1 and a[count] == 0 and (a[count + 1] == 0 or a[count + 1] == 1) and c == 1:
            flag = count + 1
            cut_off = matrix_cut[count]
            break
        else:
            count += 1

    # 创建空列表存储提取的数组
    store_matrix_1 = []
    store_matrix_2 = []
    # 存储当前压缩感知节点的状态
    matrix_p_1 = []
    matrix_p_2 = []

    for j in range(state_matrix.shape[0]):
        if count < state_matrix.shape[0]-1 and a[count] == 0 and (a[count + 1] == 0 or a[count + 1] == 1):
            # 提取第二个基本时间段的判断
            if c == 1:
                if a[flag] != a[count + 1] and dist_counter / len(cut_off) > theta:
                    cut_off = matrix_cut[count]
                    # print(f"value of cut_off_2{cut_off}")
                    c += 1
            dist_counter = 0
            for n in range(len(cut_off)):
                if cut_off[n] != matrix_cut[count][n]:
                    dist_counter += 1
                # 阈值判断
            # 存储基本时间段改变前后的两个矩阵信息la
            if c == 1:
                if dist_counter / len(cut_off) < la:
                    matrix_p_1.append(a[count + 1])
                    store_matrix_1.append(matrix_cut[count])
                    # break
            if c == 2:
                if dist_counter / len(cut_off) < la:
                    matrix_p_2.append(a[count + 1])
                    store_matrix_2.append(matrix_cut[count])
            count += 2
        else:
            count += 1

    store_matrix_1 = np.array(store_matrix_1)
    matrix_p_1 = np.array(matrix_p_1)
    new_store_matrix_1 = np.vstack(store_matrix_1)
    # 输出得到的matrix_1矩阵
    # print(f"the value of new_store_matrix_1:\n{new_store_matrix_1}")
    m_1 = new_store_matrix_1.shape[0]
    n_1 = new_store_matrix_1.shape[1]
    # 求第一个矩阵平均矩阵值
    for m in range(n_1):
        for n in range(m_1):
            avg[0][m] += new_store_matrix_1[n][m]
        avg[0][m] = avg[0][m] / m_1
    for m in range(matrix_p_1.shape[1]):
        avg_p[0] += matrix_p_1[m][0]
    avg_p[0] = avg_p[0] / matrix_p_1.shape[1]

    store_matrix_2 = np.array(store_matrix_2)
    matrix_p_2 = np.array(matrix_p_2)
    new_store_matrix_2 = np.vstack(store_matrix_2)
    # 在循环中输出得到的matrix_2，防止循环外不存在matrix_2矩阵报错
    # print(f"the value of new_store_matrix_2:\n{new_store_matrix_2}")
    m_2 = new_store_matrix_2.shape[0]
    n_2 = new_store_matrix_2.shape[1]
    # 求第二个矩阵平均矩阵值
    for m in range(n_2):
        for n in range(m_2):
            avg[1][m] += new_store_matrix_2[n][m]
        avg[1][m] = avg[1][m] / m_2

    for m in range(matrix_p_2.shape[0]):
        avg_p[1] += matrix_p_2[m][0]
    avg_p[1] = avg_p[1] / matrix_p_2.shape[1]
    avg = np.delete(avg, 1, axis=0)
    avg_p = np.delete(avg_p, 1, axis=0)

    print(f"the value of avg:\n{avg}")
    print(f"value of matrix_p:\n{avg_p}")
    print(f"value of i {i}")

    # 压缩感知
    matrix_p = avg_p
    A = avg

    constraints = ({'type': 'eq', 'fun': lambda x: np.dot(A, x) - matrix_p})
    initial_guess = np.zeros(num_n-1)

    result = minimize(objective, initial_guess, constraints=constraints)
    recovered_sparse_matrix = result.x


    # 将array转化为list将49list填充为50
    recovered_sparse_matrix = recovered_sparse_matrix.tolist()
    recovered_sparse_matrix.insert(i, 1)
    # 将list转化为array
    recovered_sparse_matrix = np.array(recovered_sparse_matrix)

    final_state_matrix.extend(recovered_sparse_matrix)
# print("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~")
# print(final_state_matrix)

final_state_matrix = np.reshape(final_state_matrix, (num_n, num_n))


count1 = 0
count1adj = 0
count0adj = 0
uneq = 0
recons_ones = 0
for i in range(num_n):
    for j in range(num_n):
        if adj_matrix[i][j] == 1:
            count1adj += 1
        else: count0adj += 1
        if final_state_matrix[i][j] == 1:
            recons_ones += 1
        if final_state_matrix[i][j] == adj_matrix[i][j] == 1:
            count1 += 1
        if final_state_matrix[i][j] == 1 and adj_matrix[i][j] == 0:
            uneq += 1

FN = count1adj-count1
TN = count0adj-uneq
print(f"原网络总边数（P）：{count1adj}")
print("正确重构率", count1/count1adj)
