import networkx as nx
import numpy as np
import matplotlib.pyplot as plt

# 创建两个随机图层
layer1 = nx.erdos_renyi_graph(100, 0.1)
layer2 = nx.erdos_renyi_graph(100, 0.1)

# 创建双层网络模型
model = nx.double_edge_swap(layer1, nswap=3, max_tries=1000)
node = 1000
# 添加边连接两个图层
for node in layer1.nodes():
    model.add_edge(node, 200)

# 绘制双层网络模型
pos = nx.spring_layout(model, seed=42)
nx.draw(model, pos, node_size=50, alpha=0.8)
nx.draw(layer1, pos, node_size=50, alpha=0.5, node_color='r', edge_color='r')
nx.draw(layer2, pos, node_size=50, alpha=0.5, node_color='b', edge_color='b')
plt.show()
